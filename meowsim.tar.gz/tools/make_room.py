# Собирает фон комнаты и спрайты из расшифрованных PNG (XOR 0x2f) исходной игры.
import os, sys
from PIL import Image
dec, out = sys.argv[1], sys.argv[2]
S = 1.8
VW, VH = 240, 286
def L(n): return Image.open(os.path.join(dec, n + '.png')).convert('RGBA')
ts = L('tileset')
def tile(c, r): return ts.crop((c*32, r*32, c*32+32, r*32+32))
room = Image.new('RGBA', (VW, VH))
WALL_H = 140
wall, floor = tile(2, 1), tile(0, 1)
for y in range(0, VH, 32):
    for x in range(0, VW, 32):
        room.paste(wall if y < WALL_H - 16 else floor, (x, y))
# плинтус
for x in range(0, VW, 32):
    room.paste(tile(0, 2).crop((0, 0, 32, 10)), (x, WALL_H - 10))
def put(n, x, y, scale=1):
    im = L(n)
    if scale != 1: im = im.resize((int(im.width*scale), int(im.height*scale)), 0)
    room.alpha_composite(im, (x, y))
put('picture', 20, 25)
put('mirror', 105, 20)
put('table', 150, 150)
put('bed_low', 12, 190, 1.2)
put('bowl', 160, 255)
put('kettle', 170, 118, 0.7)
put('flower', 20, 140, 0.9)
big = room.resize((432, int(VH*S)), 0).crop((0, 0, 432, 514))
big.convert('RGB').save(os.path.join(out, 'room.png'))
cat = L('kitty'); cat = cat.resize((int(cat.width*1.5), int(cat.height*1.5)), 0)
cat.save(os.path.join(out, 'cat.png'))
ic = L('icon').resize((64, 64), 0); ic.save(os.path.join(out, 'logo.png'))
print('ok', big.size, cat.size)
